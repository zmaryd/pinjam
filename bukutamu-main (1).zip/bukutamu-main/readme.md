export the db_bukutamu.sql to phpmyadmin

acc: admin pass: 12345
